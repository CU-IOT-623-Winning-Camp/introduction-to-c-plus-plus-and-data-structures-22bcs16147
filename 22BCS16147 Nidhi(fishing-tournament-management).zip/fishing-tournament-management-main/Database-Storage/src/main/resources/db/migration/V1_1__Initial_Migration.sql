INSERT INTO `match_result_type` (`id`, `type`) VALUES (1, 'result.win');
INSERT INTO `match_result_type` (`id`, `type`) VALUES (2, 'result.loss');
INSERT INTO `match_result_type` (`id`, `type`) VALUES (3, 'result.draw');
INSERT INTO `match_result_type` (`id`, `type`) VALUES (4, 'result.forfeit');
INSERT INTO `match_result_type` (`id`, `type`) VALUES (5, 'result.no_show');
